# NH Interactive v1.7.3 — Smart Sentences

Completed:
- NH1 Unit 1: 45 entries
- NH1 Unit 2: 51 entries
- NH1 Unit 3: 42 entries
- NH1 Unit 4: 39 entries

Unit 4 includes natural JHS-level examples, Japanese translations,
contextual fill-in-the-blank prompts, and short usage tips.

Suggested commit:
`Add NH1 Unit 4 smart sentences`
